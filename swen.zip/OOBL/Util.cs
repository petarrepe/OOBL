﻿namespace OOBL
{
    public static class Util
    {
        public enum Actions{
            NewBill,
            ReportForDay,
            ReportForArticles,
            ArticlesEdit,
            BillDeletion
        }
        public enum UnitOfSelling
        {
            Kilogram,
            Piece
        }
    }
}
